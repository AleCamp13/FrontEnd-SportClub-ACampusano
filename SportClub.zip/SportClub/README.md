# SportClub · Tu mejor versión comienza hoy

Sitio web estático (HTML5 + CSS3 + Bootstrap 5 + JS) con la identidad oficial de
**SportClub**: logo corporativo y colores morado `#2E1A47` / dorado `#F2B705`.

## Novedades de esta versión
- Landing page rediseñada (mejor calidad): hero deportivo, tarjetas de beneficios,
  planes con plan destacado, sección "Sobre el Club" y footer, todo responsivo.
- Tipografías deportivas **Anton** (titulares) + **Manrope** (texto).
- Logo oficial con fondo transparente, legible sobre morado y blanco.
- **Login** con **selector de perfil**: botones para entrar a **Usuario**, **Coach**
  y **Administrador** (Accesos rápidos para revisión).
- 100% responsivo (móvil) y listo para **GitHub Pages**.

## Estructura
```text
/css        estilos (style.css, login.css, dashboards)
/js         script.js
/assets/img imágenes y logo
/pages      login, registro, recuperar, dashboards
/index.html landing page
```

## Abrir en Visual Studio Code
1. Abrir la carpeta `SportClub` en VS Code.
2. Abrir `index.html` con **Live Server** (o doble clic en el navegador).

## Publicar en GitHub Pages
1. Crear un repositorio público y subir todo el contenido de `SportClub`.
2. `Settings > Pages` → rama `main`, carpeta `/ (root)` → **Save**.
3. La página quedará en `https://TU-USUARIO.github.io/TU-REPO/`.

> Proyecto estático: los dashboards y formularios son un prototipo visual navegable
> (sin autenticación real ni base de datos).
